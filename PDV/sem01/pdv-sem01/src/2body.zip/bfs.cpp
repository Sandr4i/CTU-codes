#include "bfs.h"

#include <unordered_set>
#include <atomic>
#include <limits>

// Naimplementujte efektivni algoritmus pro nalezeni nejkratsi cesty v grafu.
// V teto metode nemusite prilis optimalizovat pametove naroky, a vhodnym algo-
// ritmem tak muze byt napriklad pouziti prohledavani do sirky (breadth-first
// search.
//
// Metoda ma za ukol vratit ukazatel na cilovy stav, ktery je dosazitelny pomoci
// nejkratsi cesty.

state_ptr bfs(state_ptr root) {
    if (root == nullptr) return nullptr;
    if (root->is_goal()) return root;

    state_ptr ret = nullptr;
    std::vector<state_ptr> queue;
    std::unordered_set<unsigned long long> visited;
    std::atomic<unsigned int> max_cost = std::numeric_limits<unsigned int>::max();

    visited.insert(root->get_identifier());

    std::vector<state_ptr> next_root_states = root->next_states();
    for (auto &current : next_root_states) {
        if (current->is_goal()) {
            unsigned int cost = current->current_cost();
            if (cost < max_cost) {
                ret = current;
                max_cost = cost;
            }
            continue;
        }
        queue.push_back(current);
        visited.insert(current->get_identifier());
    }

    size_t queue_size;
    while (!queue.empty()) {
        queue_size = queue.size();
        #pragma omp parallel for shared(queue, visited)
        for (size_t i = 0; i < queue_size; i++) {
            state_ptr current = queue[i];
            auto id = current->get_identifier();
            auto next_states = current->next_states();
            for (auto &next : next_states) {
                auto next_id = next->get_identifier();
                unsigned int cost = next->current_cost();
                if (next->is_goal()) {
                    if (cost < max_cost) {
                        ret = next;
                        max_cost = cost;
                    }
                    continue;
                }
                else if (visited.find(next_id) != visited.end() || id == next_id || cost >= max_cost) continue;
                #pragma omp critical
                {
                    queue.push_back(next);
                    visited.insert(next_id);
                }
            }
        }
        queue.erase(queue.begin(), queue.begin() + queue_size);
    }
    return ret;
}