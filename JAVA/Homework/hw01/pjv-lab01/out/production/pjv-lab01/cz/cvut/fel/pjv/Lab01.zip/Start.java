package cz.cvut.fel.pjv;
public class Start {
   public static void main(String[] args) {
      Lab01 lab = new Lab01();
      lab.homework(args);
   }

}
